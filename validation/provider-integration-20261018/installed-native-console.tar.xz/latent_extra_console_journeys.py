import asyncio
import json
from pathlib import Path
import sys

ROOT = Path('/workspace/scratch/983c4968e2d6')
sys.path.insert(0, str(ROOT / 'ncp-baseline/tools/mcp-operator-console'))
from console import ConsoleConfig, MCPBridge
from ciw.agent_mcp import leakage_config, measured_thermal_config

OUT = ROOT / 'latent-extra-console-final'
OUT.mkdir(exist_ok=False)


async def journey(instrument):
    output = OUT / instrument
    output.mkdir()
    if instrument == 'leakage':
        profile = leakage_config(output / 'profile')
        extra = {'provider_checkout': ROOT / 'latent-fsrt-leakage', 'provider_python': Path(sys.executable)}
    else:
        profile = measured_thermal_config(output / 'profile', ROOT / 'ncp-baseline/examples/measured-thermal/source.json')
        extra = {}
    bridge = MCPBridge(ConsoleConfig(Path(sys.executable), profile, instrument=instrument,
                                    state_dir=output / 'console', **extra))
    calls = []
    await bridge.open()
    try:
        async def call(name, arguments, write=False):
            raw = await bridge.request('call', {'name': name, 'arguments': arguments, 'confirmed': write})
            assert not raw.get('isError'), raw
            calls.append({'name': name, 'arguments': arguments, 'response': raw['structuredContent']})
            return raw['structuredContent']['data']
        imported = await call('ncp_integrations_list', {'section': 'imports', 'limit': 32})
        assert imported['total'] == 21 and not imported['authorizes_execution']
        capabilities = await call('ncp_capabilities_list', {})
        template = await call('ncp_plan_template', {'baseline': 'baseline'})
        plan = await call('ncp_plan_create', {'source': 'source', 'baseline': 'baseline', 'graph': template['graph']}, True)
        digest = {'plan_id': plan['plan_id'], 'expected_digest': plan['digest']}
        await call('ncp_plan_admit', digest, True)
        submitted = await call('ncp_run_submit', {**digest, 'attempt': 'console-native'}, True)
        async with asyncio.timeout(90):
            while True:
                run = await call('ncp_run_get', {'run_id': submitted['run_id']})
                if run['state'] not in {'queued', 'running'}:
                    break
                await asyncio.sleep(.05)
        assert run['state'] == 'completed', run
        same = await call('ncp_run_submit', {**digest, 'attempt': 'console-native'}, True)
        assert same == run
        result = await call('ncp_artifact_read', {'artifact': run['result']['artifacts']['graph-run']['artifact_id'], 'selector': ['status']})
        report = {'status': 'PASS', 'instrument': instrument, 'calls': len(calls),
                  'execution_ids': run['result']['execution_ids'], 'retry_reused_run': True,
                  'operation_ids': [item['operation_id'] for item in capabilities['items']],
                  'scope': 'installed CLI/console SDK/native or reference computation over synthetic declared input; no physical qualification'}
        (output / 'calls.json').write_text(json.dumps(calls, indent=2) + '\n')
        (output / 'report.json').write_text(json.dumps(report, indent=2) + '\n')
        print(json.dumps(report), flush=True)
    finally:
        await bridge.close()


async def main():
    for instrument in ('leakage', 'measured-thermal'):
        await journey(instrument)


asyncio.run(main())
