"""Retained emit -> native windows; display observation separate from launch receipt."""
from pathlib import Path
from collections import Counter
from hashlib import sha256
import json
import os
import socket
import subprocess
import sys
import threading
import time
from PIL import ImageGrab

ROOT = Path('/workspace/scratch/983c4968e2d6/ncp-baseline')
OUT = Path(__file__).resolve().parent / 'native-projection-final'
OUT.mkdir(exist_ok=False)
SHARED = ROOT.parent
PREFIX = SHARED / 'finish-tools/system'
BEVY = ROOT / 'tools/bevy-render-view/target/debug/bevy-render-view'
GODOT = SHARED / 'finish-tools/godot/Godot_v4.5.2-stable_linux.x86_64'
PYTHON = SHARED / 'codebase-review-venv/bin/python'
env = dict(os.environ, LD_LIBRARY_PATH=str(PREFIX / 'usr/lib/x86_64-linux-gnu'),
           DISPLAY='127.0.0.1:98', VK_ICD_FILENAMES=str(SHARED / 'finish-tools/lvp_icd.json'),
           WGPU_BACKEND='vulkan')
env.pop('PYTHONPATH', None)
report = {'may_authorize': False, 'physical_qualification': 'NOT_ESTABLISHED', 'journeys': []}
contacts = []
stop = threading.Event()
listener = socket.socket()
listener.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
listener.bind(('127.0.0.1', 8765))
listener.listen()
listener.settimeout(.1)
def listen():
    while not stop.is_set():
        try:
            connection, address = listener.accept()
            contacts.append(address)
            connection.close()
        except socket.timeout:
            pass
thread = threading.Thread(target=listen, daemon=True)
thread.start()
display_log = (OUT / 'display.log').open('w')
display = subprocess.Popen([str(PREFIX / 'usr/bin/Xvfb'), ':98', '-screen', '0', '1280x900x24',
    '-nolisten', 'unix', '-nolisten', 'local', '-listen', 'tcp', '-ac', '-fp', 'built-ins'],
    env=env, stdout=display_log, stderr=subprocess.STDOUT)
try:
    for _ in range(50):
        if display.poll() is not None:
            raise RuntimeError('Software display exited')
        try:
            with socket.create_connection(('127.0.0.1', 6098), timeout=.2):
                break
        except OSError:
            time.sleep(.1)
    for client, binary in [('bevy', BEVY), ('godot', GODOT)]:
        receipt = OUT / (client + '-launch.json')
        command = [str(PYTHON), str(ROOT / 'examples/workflows/emit_all_usecases.py'),
            '--scenario', 'geodesic-input-review', '--output-root', str(OUT / 'same-records'),
            '--receipt', str(receipt), '--client', client, '--binary', str(binary),
            '--frames', '240', '--timeout', '90']
        with (OUT / (client + '-host.log')).open('w') as log:
            process = subprocess.Popen(command, cwd=ROOT, env=env, stdout=log, stderr=subprocess.STDOUT)
            screenshot = None
            deadline = time.monotonic() + 100
            while process.poll() is None and time.monotonic() < deadline:
                time.sleep(.12)
                frame = ImageGrab.grab(xdisplay=env['DISPLAY']).convert('RGB')
                if client == 'bevy':
                    pixels = sum(1 for red, green, blue in frame.getdata()
                        if green > 140 and red < 180 and green > red * 1.2 and blue > red * 1.2)
                else:
                    # Visible light text on the dark teaching canvas; the
                    # label semantics are separately exercised in Godot smoke.
                    pixels = sum(1 for red, green, blue in frame.getdata()
                        if min(red, green, blue) > 120)
                if pixels > (25 if client == 'bevy' else 1500) and screenshot is None:
                    screenshot = OUT / (client + '-window.png')
                    frame.save(screenshot)
                    observation = {'visible_pixels': pixels, 'screenshot_sha256': sha256(screenshot.read_bytes()).hexdigest()}
            code = process.wait(timeout=5)
        data = json.loads(receipt.read_bytes())
        launch = data['projector']
        assert code == 0 and launch['status'] == 'COMPLETED', data
        assert 'NCP_PROJECTOR_FRAMES_COMPLETE' in launch['stdout'], launch
        assert not any(marker in launch['stderr'] for marker in ['SCRIPT ERROR', 'ERROR:', 'panicked']), launch
        assert screenshot is not None, 'No visible content observed: ' + client
        assert launch['input_unchanged'] is True
        report['journeys'].append({'client': client, 'status': 'PASS', 'receipt': receipt.name,
            'input_sha256': launch['input_sha256'], **observation})
    assert report['journeys'][0]['input_sha256'] == report['journeys'][1]['input_sha256']
    for name, offset in [('origin', 0), ('translated', 10**12)]:
        record = OUT / (name + '.json')
        record.write_text(json.dumps({'status': 'HISTORICAL', 'points': [[offset+i, 0, 0] for i in range(3)]}))
        probe = subprocess.run([sys.executable, str(ROOT / 'scripts/check_bevy_projector.py'),
            '--binary', str(BEVY), '--render', str(record), '--output-dir', str(OUT / name)],
            cwd=ROOT, env=env, capture_output=True, text=True, timeout=100)
        (OUT / (name + '-probe.log')).write_text(probe.stdout + probe.stderr)
        assert probe.returncode == 0, probe.stdout + probe.stderr
        report['journeys'].append({'case': name, **json.loads((OUT / name / 'gate.json').read_bytes())})
    report['session_connections'] = len(contacts)
    assert not contacts, 'Retained projection contacted Session'
    report['status'] = 'PASS'
finally:
    stop.set()
    thread.join(timeout=2)
    listener.close()
    display.terminate()
    display.wait(timeout=5)
    display_log.close()
    (OUT / 'journey.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report), flush=True)
