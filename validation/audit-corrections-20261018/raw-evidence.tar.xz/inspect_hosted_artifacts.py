"""Inspect retained baseline archives without executing their contents."""
from hashlib import sha1, sha256
from io import BytesIO
import json
from pathlib import Path
import xml.etree.ElementTree as ET
import zipfile

ROOT = Path('/workspace/scratch/983c4968e2d6/ncp-baseline')
OUT = Path(__file__).resolve().parent
BASELINE = '312a37ba613a0b57ea027b8d00df5b3b4fe08d69'
artifacts = OUT / 'hosted-artifacts'
manifest = json.loads((artifacts / 'manifest.json').read_bytes())
tree = json.loads((OUT / 'baseline-package-tree.json').read_bytes())
assert tree['baseline_sha'] == BASELINE
source = {row['path'].removeprefix('src/'): row['sha'] for row in tree['files']}
report = {'baseline_sha': BASELINE, 'qualification': 'NOT_CLOSED', 'waivers': [], 'artifacts': []}
latest = {row['id']: row for row in json.loads((OUT / 'hosted-baseline-latest.json').read_bytes())['required_runs']}
for row in manifest:
    path = artifacts / row['archive']
    assert sha256(path.read_bytes()).hexdigest() == row['sha256']
    assert row['artifact']['workflow_run']['head_sha'] == BASELINE
    checked = {'artifact_id': row['artifact']['id'], 'name': row['artifact']['name'],
        'run_id': row['artifact']['run_id'], 'run_status_at_download': row['artifact']['run_status'],
        'run_conclusion_at_download': row['artifact']['run_conclusion'], 'sha256': row['sha256'],
        'members': len(row['members']), 'xml_reports': [], 'candidate_records': [], 'acceptance_reports': [], 'non_json_outputs': []}
    current = latest[row['artifact']['run_id']]
    checked.update(latest_run_status=current['status'], latest_run_conclusion=current['conclusion'])
    with zipfile.ZipFile(path) as archive:
        assert archive.testzip() is None
        for name in archive.namelist():
            if name.endswith('.xml'):
                try:
                    xml = ET.fromstring(archive.read(name))
                except ET.ParseError:
                    continue
                suites = list(xml.iter('testsuite'))
                if suites:
                    checked['xml_reports'].append({'path': name, **{key: sum(int(s.get(key, 0)) for s in suites)
                        for key in ('tests', 'failures', 'errors', 'skipped')}})
            if name.endswith('.json'):
                try:
                    value = json.loads(archive.read(name))
                except json.JSONDecodeError:
                    checked['non_json_outputs'].append(name)
                    continue
                if isinstance(value, dict) and 'candidate_sha' in value:
                    assert value['candidate_sha'] == BASELINE, (name, value)
                    checked['candidate_records'].append({'path': name, 'record': value})
                if isinstance(value, dict) and value.get('schema') in {
                    'ciw.release-operator-acceptance.v1', 'ciw.release-operator-journey.v1'}:
                    assert value['status'] == 'PASS', (name, value['status'])
                    checked['acceptance_reports'].append({'path': name, 'status': value['status'],
                        'scope': value.get('scope', value.get('kind')), 'authority': value['authority'],
                        'checks': len(value.get('checks', []))})
                if name == 'resources.json':
                    checked['resources'] = value
        if row['artifact']['name'].startswith('release-operator'):
            candidate = checked['candidate_records'][0]['record']
            wheel_name = next(n for n in archive.namelist() if n.endswith('.whl'))
            wheel_bytes = archive.read(wheel_name)
            assert sha256(wheel_bytes).hexdigest() == candidate['wheel_sha256']
            matched = 0
            with zipfile.ZipFile(BytesIO(wheel_bytes)) as wheel:
                for info in wheel.infolist():
                    if info.filename.startswith('ciw/') and not info.is_dir():
                        raw = wheel.read(info)
                        blob = sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest()
                        assert source[info.filename] == blob, info.filename
                        matched += 1
            checked['wheel'] = {'sha256': candidate['wheel_sha256'], 'package_files_byte_matched_to_baseline_tree': matched}
            assert len(checked['acceptance_reports']) == 4
            assert checked['xml_reports'] and all(r['failures'] == r['errors'] == r['skipped'] == 0 for r in checked['xml_reports'])
            checked['disposition'] = 'PASS: same-SHA scripted installed operator lane on the recorded platform'
        elif row['artifact']['name'] == 'proved-heat-native-evidence':
            assert [r['path'] for r in row['members']] == ['resources.json']
            checked['disposition'] = 'NOT_QUALIFIED: runner resource preflight failed before native proving'
        elif current['status'] == 'completed' and current['conclusion'] == 'success':
            checked['disposition'] = 'COMPLETED: same-SHA workflow success; provider and physical scope follows the retained reports'
        else:
            checked['disposition'] = 'PARTIAL: retained job evidence does not close the still-incomplete workflow'
    report['artifacts'].append(checked)
(OUT / 'hosted-artifact-inspection.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'artifacts_checked': len(report['artifacts']), 'release_operator': [r['wheel'] for r in report['artifacts'] if 'wheel' in r]}))
