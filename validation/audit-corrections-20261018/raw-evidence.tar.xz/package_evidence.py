"""Retain final checks and receipts; omit temporary authority configurations."""
from pathlib import Path
from hashlib import sha256
import io
import json
import shutil
import tarfile
import zipfile

ROOT = Path('/workspace/scratch/983c4968e2d6/ncp-baseline')
OUT = Path(__file__).resolve().parent
DEST = ROOT / 'validation/audit-corrections-20261018'
assert (OUT / 'isolated-regression/summary.json').is_file(), 'Full sweep is not complete'
DEST.mkdir(parents=True, exist_ok=True)
excluded = {'core-regressions-before.log', 'core-regressions-after.log', 'native-projection.log'}
files = [p for p in OUT.iterdir() if p.is_file() and p.name not in excluded
         and p.suffix in {'.log', '.xml', '.json', '.ini', '.py', '.md'}]
for folder in ['isolated-regression', 'native-projection-final', 'hosted-job-logs', 'atomic-native']:
    files += [p for p in (OUT / folder).rglob('*') if p.is_file()]
for folder, names in {
    'installed-operator-journey': ['report.json', 'journey-receipts.json', 'representative-investigation.json'],
    'installed-http-journey': ['report.json'],
    'hosted-artifacts': ['manifest.json'],
}.items():
    files += [OUT / folder / n for n in names if (OUT / folder / n).is_file()]
files = sorted(set(files))
members = []
archive = DEST / 'raw-evidence.tar.xz'
with tarfile.open(archive, 'w:xz', preset=6) as target:
    for p in files:
        raw = p.read_bytes()
        name = str(p.relative_to(OUT))
        info = tarfile.TarInfo(name)
        info.size = len(raw)
        info.mode = 0o644
        info.mtime = 0
        target.addfile(info, io.BytesIO(raw))
        members.append({'path': name, 'bytes': len(raw), 'sha256': sha256(raw).hexdigest()})
(DEST / 'archive-manifest.json').write_text(json.dumps({'archive': archive.name,
    'sha256': sha256(archive.read_bytes()).hexdigest(), 'members': members}, indent=2) + '\n')
for name in ['summary.json', 'published-code-identity.json', 'source-identity.json', 'wheel-identity.json',
             'hosted-baseline-observation.json', 'hosted-artifact-inspection.json']:
    shutil.copyfile(OUT / name, DEST / name)
(DEST / 'SHA256SUMS').write_text(''.join(sha256(p.read_bytes()).hexdigest() + '  ' + p.name + '\n'
    for p in sorted(DEST.iterdir()) if p.is_file() and p.name != 'SHA256SUMS'))
delivery = ROOT.parent / 'deliverables/NCP-audit-corrections-20261018.zip'
with zipfile.ZipFile(delivery, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as target:
    for p in sorted(DEST.iterdir()):
        if p.is_file():
            target.write(p, 'audit-corrections/' + p.name)
    target.write(ROOT / 'docs/AUDIT_CORRECTIONS_20261018.md', 'NCP-audit-corrections-20261018.md')
    # These are original hosted archives, not repacked substitutes. Their
    # identities and every member digest are retained in manifest.json.
    for p in sorted((OUT / 'hosted-artifacts').glob('*.zip')):
        target.write(p, 'hosted-artifacts/' + p.name, compress_type=zipfile.ZIP_STORED)
    wheel = next((OUT / 'dist').glob('*.whl'))
    target.write(wheel, 'wheel/' + wheel.name, compress_type=zipfile.ZIP_STORED)
with zipfile.ZipFile(delivery) as check:
    assert check.testzip() is None
print(json.dumps({'archive_bytes': archive.stat().st_size, 'retained_members': len(members),
    'delivery': str(delivery), 'delivery_bytes': delivery.stat().st_size,
    'delivery_sha256': sha256(delivery.read_bytes()).hexdigest()}))
