# Independent review of the correction and retained-projector patch

Verdict: no required changes or merge-blocking defects found in the reviewed patch.

Scope: unstaged changes in the operational host/store/CLI, Session and Workbench identity retention, retained-render writer and catalog exporter, Godot retained mode and status projection, Bevy display fitting, associated new tests, and the retained-render schema/documentation. Staged integration-completion evidence and the three missing source-retirement archive parts were excluded as instructed. Review followed the code-review-and-quality skill, with emphasis on correctness, authority, security, compatibility, and performance.

Findings checked:

- First-publication detection is backed by immutable journal CAS; an identical historical finding retry cannot repoint the current head. A missing head is treated as stale, including interrupted publication. The approval regression exercises dispatch refusal after reopening the host.
- CLI dispatch now uses a separate action attribute, leaving the command-reference argument intact.
- Session reopen checks the complete retained identity set. Reproduction execution, result, and numerical-result identities are claimed across validated workflow families. Declared workflow step claim shapes remain compatible with replay receipts that embed those steps.
- Godot normalizes status whitespace/case and accepts only a boolean true freshness flag, including both card status fields. The retained launch mode returns before constructing or connecting the Session client.
- Bevy fits retained coordinates in binary64 before converting the resulting display coordinates to binary32. Existing coordinate limits keep bound arithmetic finite; empty and degenerate paths are covered.
- The shared exporter selects an absolute executable from explicit host arguments, launches with an argument list and no shell, validates all catalog entries before writing, and checks receipt/render/executable collisions. Launch receipts explicitly separate process completion from display observation and native qualification.

Independent verification:

```text
python -m pytest -q tests/test_workspace_occurrence_collisions.py tests/test_machine_workflow.py tests/test_teaching_corpus.py tests/test_operational_engineering.py -k 'workspace or replay or teaching or historical_finding or missing_finding_head or publication or supervisory_configuration'
33 passed, 40 deselected in 7.67s
```

Limitations: this review did not repeat the full isolated suite, compile the viewer, or independently observe a graphical window. The author-provided Godot/Rust evidence was not represented as an independently executed check. Process-output tails in the receipt are bounded, but subprocess.run captures output in memory until process completion; that remains a nonblocking limitation for explicitly selected local projector executables. Optional process deadlines and frame limits must be supplied by the operator when a bounded run is desired. This review does not qualify native providers, physical operation, hosted CI, or the frozen baseline.
