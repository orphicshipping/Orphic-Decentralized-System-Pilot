import asyncio
from hashlib import sha256
import json
from pathlib import Path
import subprocess
import sys

from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client

ROOT = Path('/workspace/scratch/983c4968e2d6')
OUT = ROOT / 'latent-agent-native'
OUT.mkdir(exist_ok=False)
inspection = ROOT / 'ncp-baseline/examples/metrology-clearance/uncertain-inspection.json'
provider = ROOT / 'latent-cse'
revision = 'f1ceeae28168de32ca9aea44f7b6d67d2090677e'
command = [sys.executable, '-I', '-m', 'ciw.net', 'control', 'prepare-bim', '--inspection', str(inspection), '--output-dir', str(OUT / 'profile')]
subprocess.run(command, check=True, capture_output=True)
profile = OUT / 'profile/profile.json'
calls = []


async def main():
    first = None
    protocols = []
    for modern in (True, False):
        args = ['-I', '-m', 'ciw.net', 'agent', 'serve', '--sdk', '--profile', str(profile),
                '--instrument', 'bim-clearance', '--provider-checkout', str(provider),
                '--provider-revision', revision, '--python', sys.executable]
        if not modern:
            args.append('--resume')
        params = StdioServerParameters(command=sys.executable, args=args, cwd=str(OUT))
        with (OUT / ('modern.log' if modern else 'legacy.log')).open('w') as errors:
            async with stdio_client(params, errlog=errors) as (read, write):
                async with ClientSession(read, write, read_timeout_seconds=60) as client:
                    await (client.discover() if modern else client.initialize())
                    protocols.append(client.protocol_version)
                    async def call(name, arguments):
                        result = await client.call_tool(name, arguments)
                        assert not result.is_error, result
                        assert json.loads(result.content[0].text) == result.structured_content
                        calls.append({'protocol': client.protocol_version, 'name': name,
                                      'arguments': arguments, 'response': result.structured_content})
                        return result.structured_content
                    capabilities = await call('net_capabilities', {})
                    native = capabilities['catalog']['operations']['metrology.bim-clearance.v1']['runtime']['native']
                    assert native['revision'] == revision
                    assert native['source_tree'] == 'f91c982b580ad4f16a27ea149eedf0e338f6d764'
                    value = await call('net_execute', {'source': 'source', 'graph': 'baseline', 'attempt': 'native-agent-first'})
                    assert value['status'] == 'completed'
                    if modern:
                        first = value
                    else:
                        assert value['reused_response'] and value['execution_ids'] == first['execution_ids']
                        fresh = await call('net_replay', {'original_attempt': 'native-agent-first', 'new_attempt': 'native-agent-fresh'})
                        assert fresh['status'] == 'completed' and fresh['execution_ids'] != first['execution_ids']
                    payload = await call('net_inspect', {'artifact': value['artifacts']['graph-run']['artifact_id'],
                        'selector': ['nodes', 'assess', 'result', 'data']})
                    assert payload['data']['native']['posterior']['verdict'] == 'UNRESOLVED'
                    assert payload['data']['authority']['physical_qualification'] == 'not_established'
    assert protocols == ['2026-07-28', '2025-11-25']
    report = {'status': 'PASS', 'protocols': protocols, 'calls': len(calls),
              'provider_revision': revision, 'source_tree': native['source_tree'],
              'original_execution_ids': first['execution_ids'], 'fresh_execution_ids': fresh['execution_ids'],
              'resume_retry_reused_execution': True, 'inspection_sha256': sha256(inspection.read_bytes()).hexdigest(),
              'scope': 'installed CLI preparation and native agent SDK modern/legacy; synthetic geometry; no physical qualification'}
    (OUT / 'calls.json').write_text(json.dumps(calls, indent=2) + '\n')
    (OUT / 'report.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps(report))


asyncio.run(main())
